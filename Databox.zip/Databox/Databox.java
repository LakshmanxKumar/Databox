package Databox;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.StringBuilder;
import java.util.ArrayList;

public class Databox {

    private  File row;
    protected ArrayList<String> fileData= new ArrayList<String>();
    private int key=0;
    private boolean isEncrypted=false;
    
// Constructors -- -- -- -- -- 
    public Databox(String fileName){
        fileName=System.getProperty("user.dir")+"\\src"+"\\Databox\\"+"Storage\\"+fileName+".txt";
        row=new File(fileName);
        if(!row.exists()){
        addToFile(""); }
        fileData=this.getAllFromFile();

    }
    public Databox(String fileName, int key){
        fileName=System.getProperty("user.dir")+"\\src"+"\\Databox\\"+"Storage\\"+fileName+".txt";
        row=new File(fileName);
        if(!row.exists()){
        addToFile(""); }
        this.key=key;
        isEncrypted=true;
        fileData=this.getAllFromFile();
    }
    
    public Databox(String fileName, String path){
    	fileName=path+"\\"+fileName+".txt";
        row=new File(fileName);
        if(!row.exists()){
        addToFile(""); }
        fileData=this.getAllFromFile();

    }
    
    public Databox(String fileName, int key, String path){
    	fileName=path+"\\"+fileName+".txt";
        row=new File(fileName);
        if(!row.exists()){
        addToFile(""); }
        this.key=key;
        isEncrypted=true;
        fileData=this.getAllFromFile();
    }


// methods for internal operations
    private void addToFile(String line){
        if(this.isEncrypted){
            line=encryptData(this.key, line);
        }
        try {
        FileWriter fw= new FileWriter(this.row,true);
        BufferedWriter writer= new BufferedWriter(fw);
        writer.write(line);
        writer.newLine();
        writer.close();
    }  catch (IOException e) {
            e.printStackTrace();
        }        
    }

       
    private ArrayList<String> getAllFromFile(){
        ArrayList<String> arr= new ArrayList<String>();
        if(this.isEncrypted){
        try{
        FileReader fr= new FileReader(this.row);
        BufferedReader reader= new BufferedReader(fr);
        reader.readLine();
        String line;
        while((line=reader.readLine())!=null){
            // String temp=reader.readLine();
            arr.add(decryptData(this.key, line));
        }
        reader.close();
        }catch (IOException e) {
        e.printStackTrace();
        }
        return arr;
        }else{
        try{
            FileReader fr= new FileReader(this.row);
            BufferedReader reader= new BufferedReader(fr);
            reader.readLine();
            String line;
        while((line=reader.readLine())!=null){
            arr.add(line);
        }
            reader.close();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return arr;
        }
        
    } 

    private void clearAll(){
            try{
            FileWriter fw= new FileWriter(this.row);
            fw.write("\n");
            fw.close();
        }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    
    


// -- -- methods for users
    public void add(String line){
        this.fileData.add(line);
    }

    public void commit(){
        this.clearAll();
        for(String i: fileData){
            this.addToFile(i);
        }
    }

    public void delete(int i){
        this.fileData.remove(i-1);
    }

    public void insert(int i,String line){
        this.fileData.add(i-1,line);
    }

    public void clearEverything(){
        this.fileData.clear();
    }

    public void modify(int i,String line){
        this.fileData.set(i-1,line);
    }

    public String[] getAll(){
        return this.fileData.toArray(new String[this.fileData.size()]);
    }

    public int getSize(){
        return this.fileData.size();
    }

    public String peek(){
        return this.fileData.get(this.fileData.size()-1);
    }

    public void insertAtFirst(String line){
        insert(1, line);
    }

    public void deleteLast(){
        delete(this.fileData.size());
    }

    public int search(String x){
        
        return this.fileData.indexOf(x)+1;
    }
    public String get(int index){
        return this.fileData.get(index-1);
    }

    public int countOf(String x){
        int count=0;
        for(String i : this.fileData){
            if(x.equals(i)){
            count++;}
        }
        return count;
    }

    public int binarySearch(String x){
        try{
             int find= Integer.parseInt(x);
             return binarySearch(find);
        }catch(Exception e){
            return -100;
        }
    }
    
    public int binarySearch(int x){
        try {
            int low=0;
            int high=(this.fileData).size()-1;

            while(low<=high){ 
                int mid= (low+high)/2;
                int val=Integer.parseInt(this.fileData.get(mid));
                if(val==x){
                    return mid;
                }else if(val>mid){
                    high=mid-1;
                }else{
                    low=mid+1;
                }
            }
            return -1;

        } catch (Exception e) {
            return -100;
        }
    }
    
     
    // Encrption method
    // It is not recommended to use 0 in the key
        private String encryptData(int key, String line){
            StringBuilder ans= new StringBuilder("");
            int l=line.length();
            int temp=key;
            for(int i=0;i<l;i++){

                if(temp==0){temp=key;}

                int t=temp%10;
                temp=temp/10;

                char c=line.charAt(i);
                int x=(int)c+t;
                if(x>126){
                    x=x-126+31;
                }
                c=(char)(x);
                ans.append(c);
            }
            return ans.toString();
        }

    // Decryption method
    // It is not recommended to use 0 in the key
        private String decryptData(int key, String encodedLine){
            StringBuilder ans = new StringBuilder("");
            int l = encodedLine.length();
            int temp = key;
        
            for (int i = 0; i < l; i++) {
                if (temp == 0) {
                    temp = key;
                }
                int t = temp % 10;
                temp = temp / 10;
        
                char c = encodedLine.charAt(i);
                int x = (int) c - t;
                if (x < 32) {
                    x = x + 126 - 31;
                }
                c = (char) (x);
                ans.append(c);
            }
            return ans.toString();
        }
    }