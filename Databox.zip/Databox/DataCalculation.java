package Databox;

import java.util.ArrayList;

public class DataCalculation {
        
    // Sums all the elements, unsuitable elements result in exception
    public double sumDatabox(Databox box){
        double sum=0;
        for(String i:box.fileData){
            sum=sum + Double.parseDouble(i);
        }
        return sum;
    }

    
    // returns average of the values in databox
    public double average(Databox box){
        double sum=0;
        for(String i:box.fileData){
            sum=sum + Double.parseDouble(i);
        }
        return sum/box.getSize();
    }


    // returns the largest element in the databox
    public double getLargest(Databox box){
        double x=0;
        double largest=Integer.MIN_VALUE;
        for(String i:box.fileData){
            x= Double.parseDouble(i);
            if(x>largest){largest=x;}
        }
        return largest;
    }

    // returns the smallest element in the databox
    public double getSmallest(Databox box){
        double x=0;
        
        double smallest=Integer.MAX_VALUE;
        for(String i:box.fileData){
            x= Double.parseDouble(i);
            if(x<smallest){smallest=x;}
        }
        return smallest;
    }

   

    // return the index of largest element in dropbox
    public int getIndexOfLargest(Databox box){
        double x=0;
        int index=0;
        double largest=Integer.MIN_VALUE;
        int l=box.fileData.size();
        for(int i=0;i<l;i++){
            x= Double.parseDouble(box.fileData.get(i));
            if(x>largest){
                largest=x;
                index=i;
            }
        }
        return (int)index+1;
    }

    // return the index of smallest element in dropbox
    public int getIndexOfSmallest(Databox box){
        double x=0;
        int index=0;
        double smallest=Integer.MAX_VALUE;
        int l=box.fileData.size();
        for(int i=0;i<l;i++){
        	 x= Double.parseDouble(box.fileData.get(i));
            if(x<smallest){
                smallest=x;
                index=i;
            }
        }
        return (int)index+1;
    }
    
    public String[] getAllGreaterThan(Databox box, float x ) {
    	ArrayList<String> ans= new ArrayList<>();
    	int l=box.fileData.size();
    	for(int i=0;i<l;i++) {
    		if(Float.parseFloat(box.fileData.get(i))>x) {
    			ans.add(box.fileData.get(i));
    		}
    	}
    	
    	return ans.toArray(new String[ans.size()]);
    }
    


	public String[] getAllGreaterThanAndEqualsTo(Databox box, float x ) {
		ArrayList<String> ans= new ArrayList<>();
		int l=box.fileData.size();
		for(int i=0;i<l;i++) {
			if(Float.parseFloat(box.fileData.get(i))>=x) {
				ans.add(box.fileData.get(i));
			}
		}
		
		return ans.toArray(new String[ans.size()]);
	}
	
	public String[] getAllSmallerThanAndEqualsTo(Databox box, float x ) {
		ArrayList<String> ans= new ArrayList<>();
		int l=box.fileData.size();
		for(int i=0;i<l;i++) {
			if(Float.parseFloat(box.fileData.get(i))<=x) {
				ans.add(box.fileData.get(i));
			}
		}
		
		return ans.toArray(new String[ans.size()]);
	}
	
	public String[] getAllSmallerThan(Databox box, float x ) {
		ArrayList<String> ans= new ArrayList<>();
		int l=box.fileData.size();
		for(int i=0;i<l;i++) {
			if(Float.parseFloat(box.fileData.get(i))<x) {
				ans.add(box.fileData.get(i));
			}
		}
		
		return ans.toArray(new String[ans.size()]);
	}

}
